print("ciao")
